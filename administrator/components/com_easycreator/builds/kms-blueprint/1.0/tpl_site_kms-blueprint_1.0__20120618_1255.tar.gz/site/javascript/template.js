/**
 * @version SVN: $Id: header.php 18 2010-11-08 01:10:19Z elkuku $
 * @package    kms-blueprint
 * @subpackage Js
 * @author     K.-Michael Siebenlist {@link http://www.kms-net.de}
 * @author     Created on 27-May-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');
